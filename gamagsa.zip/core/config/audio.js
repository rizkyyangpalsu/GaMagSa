var audio = {
    "flipsound" : new Audio("assets/audio/pageflip.mp3"),
    "music"     : new Audio("assets/audio/Sailing.mp3"),
};